<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
$config['appId'] = '831796966902401'; 
$config['secret'] = 'ef19b636f8bbe614d94f3c324aaa7d20';
?> 