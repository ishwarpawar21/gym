<!---start-subfooter---->
		<div class="subfooter">
			<div class="wrap">
				<ul>
					<li><a href="index.html">Home</a><span>|</span></li>
					<li><a href="destinations.html">Gyms</a><span>|</span></li>
					<li><a href="criuses.html">About us</a><span>|</span></li>
					<li><a href="destinations.html">Contact Us</a></li>
					<div class="clear"> </div>
				</ul>
				<p class="copy-right">All Rights Reserved by <a href="http://www.creowebtech.com/">Creo webtech</a></p>
				<a class="to-top" href="#header"><span> </span> </a>
			</div>
		</div>
		<!---//End-subfooter---->
		<!----//End-wrap---->
	</body>
</html>
