	<!-- end: Content -->
	</div><!--/#content.span10-->
		</div><!--/fluid-row-->
		
		
	 <div class="clearfix"></div>
	
	<footer>

		<p>
			<span style="text-align:left;float:left"><a style="text-decoration: none">Gym Website Dashboard</a></span>
			
		</p>

	</footer>
	
	<!-- start: JavaScript-->

		<script src="<?=base_url()?>assets/dashboard/js/jquery-1.9.1.min.js"></script>
	<script src="<?=base_url()?>assets/dashboard/js/jquery-migrate-1.0.0.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery-ui-1.10.0.custom.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.ui.touch-punch.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/modernizr.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/bootstrap.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.cookie.js"></script>
	
		<script src='<?=base_url()?>assets/dashboard/js/fullcalendar.min.js'></script>
	
		<script src='<?=base_url()?>assets/dashboard/js/jquery.dataTables.min.js'></script>

		<script src="<?=base_url()?>assets/dashboard/js/excanvas.js"></script>
	<script src="<?=base_url()?>assets/dashboard/js/jquery.flot.js"></script>
	<script src="<?=base_url()?>assets/dashboard/js/jquery.flot.pie.js"></script>
	<script src="<?=base_url()?>assets/dashboard/js/jquery.flot.stack.js"></script>
	<script src="<?=base_url()?>assets/dashboard/js/jquery.flot.resize.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.chosen.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.uniform.min.js"></script>
		
		<script src="<?=base_url()?>assets/dashboard/js/jquery.cleditor.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.noty.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.elfinder.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.raty.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.iphone.toggle.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.uploadify-3.1.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.gritter.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.imagesloaded.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.masonry.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.knob.modified.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/jquery.sparkline.min.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/counter.js"></script>
	
		<script src="<?=base_url()?>assets/dashboard/js/retina.js"></script>

		<script src="<?=base_url()?>assets/dashboard/js/custom.js"></script>
	<!-- end: JavaScript-->
	
</body>
</html>