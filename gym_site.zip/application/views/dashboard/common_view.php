<?php
	$this->load->view('dashboard/dashboard-header');
	$this->load->view('dashboard/');
	$this->load->view('dashboard/dashboard-footer');
	
?>