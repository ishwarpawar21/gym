<!-- start: Content -->
<div id="content" class="span10">
	<ul class="breadcrumb">
		<li>
			<i class="icon-home"></i>
			<a href="index.html">Home</a> 
			<i class="icon-angle-right"></i>
		</li>
		
		<li>
			<a href="#">Dashboard</a>
		</li>
	</ul>

	 		
			
			
			<div class="row-fluid" style="min-height: 476px;height: auto;">
			
			</div><!--/row-->

</div><!--/.content-->
	
		
