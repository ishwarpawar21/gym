<form enctype="multipart/form-data" method="post">
	
	<input type="file" name="files1"/>
	<input type="file" name="files2"/>
	 
	<input type="submit" name="sub_files"/>
</form>